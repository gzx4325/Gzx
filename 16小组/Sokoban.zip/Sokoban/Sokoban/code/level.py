def level_list():
    level_1 = [
        #第一关
        'RRXXXRRR',
        'UTXOXSSS',
        'UTX XXXX',
        'XXXB BOX',
        'XO BPXXX',
        'XXXXBXTT',
        'UUUXOXUU',
        'SSSXXXSS'
        ]
    level_2 = [
        #第二关
        'TXXXXRRR',
        'TX OXXXX',
        'XXO    X',
        'XOO XX X',
        'X B  B X',
        'XX BBXXX',
        'UX P XSS',
        'UXXXXXSU'
        ]
    level_3 = [
        #第三关
        'TTXXXXXXRR',
        'TTX    XXX',
        'UUX B    X',
        'XXX B XX X',
        'XOOO B   X',
        'XOOOBXB  X',
        'XXXX X B X',
        'SSTX  P  X',
        'RSUXXXXXXX'
        ]
    level_4 = [
        #第四关
        'TUSXXXXXX',
        'XXXX   PX',
        'X   BB  X',
        'XOXXOXXOX',
        'X   B   X',
        'X  BOX XX',
        'XXXX   XR',
        'TUSXXXXXR'
        ]
    level_5 = [
        #第五关
        'TXXXXXXXU',
        'XX     XX',
        'X  BOB  X',
        'X BXOXB X',
        'X OOPOO X',
        'X BXOXB X',
        'X  BOB  X',
        'X      XX',
        'XXXXXXXXS'
        ]
    #设置一个list，把每一个关卡都加进去，最后返回list
    levels = []
    levels.append(level_1)
    levels.append(level_2)
    levels.append(level_3)
    levels.append(level_4)
    levels.append(level_5)
    return(levels)
