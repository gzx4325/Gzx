#海龟turtle
import turtle
import os
#os.system('level.py')
#import an
from code import level

#import tkinter
#from tkinter import *


import pygame
from pygame.locals import *

#初始化pygame
pygame.init()
#pygame.mixer是一个用来处理声音的模块，其含义为“混音器”。
#pygame.mixer启动与初始化
pygame.mixer.init()
#播放声音文件  使用pygame.mixer中的music模块
pygame.mixer.music.load('music\EineLiebe.mp3')
#设置音量
pygame.mixer.music.set_volume(0.5)
#开始播放音乐流
pygame.mixer.music.play(loops=-1)


ms = turtle.Screen()
ms.setup(600,800,200,0)         #窗口大小
ms.bgcolor("cyan")            #窗口颜色：#+六个数字、“颜色英文”
ms.title("16组-推箱子")      #窗口的名字


ms.register_shape(os.path.join('E:/Sokoban/Sokoban/picture/wall.gif'))
ms.register_shape('E:/Sokoban/Sokoban/picture/o.gif')
ms.register_shape('E:/Sokoban/Sokoban/picture/p.gif')
ms.register_shape('E:/Sokoban/Sokoban/picture/box.gif')
ms.register_shape('E:/Sokoban/Sokoban/picture/boxc.gif')
ms.register_shape('E:/Sokoban/Sokoban/picture/Tree_Short.gif')
ms.register_shape('E:/Sokoban/Sokoban/picture/Tree_Tall.gif')
ms.register_shape('E:/Sokoban/Sokoban/picture/Tree_Ugly.gif')
ms.register_shape('E:/Sokoban/Sokoban/picture/Rock.gif')

#表示屏幕的刷新
ms.tracer(0)

#关卡
levels = level.level_list()

#引用类
class Pen(turtle.Turtle):
    #初始化
    #shape不同的东西shape不一样
    def __init__(self,pic):
        #继承
        super().__init__()
        #共同的属性
        self.shape(pic)
        #抬起画笔——画笔画出的线不显示
        self.penup()
    #判断人物去的位置
    def move(self, x, y, px, py):
        gox, goy = x + px, y + py
        if(gox, goy) in go_space:
            self.goto(gox, goy)
        if(gox+px, goy +py) in go_space and (gox, goy) in box_space:
            #找到箱子并推走
            for i in box_list:
                if i.pos() == (gox, goy):
                    go_space.append(i.pos())
                    box_space.remove(i.pos())
                    i.goto(gox + px, goy + py)
                    self.goto(gox, goy)
                    #更新位置
                    go_space.append(i.pos())
                    box_space.append(i.pos())
                    if i.pos() in correct_box_space:
                        i.shape('E:/Sokoban/Sokoban/picture/boxc.gif')

                        """
                        pygame.mixer.music.load('music\WorldSceneBGM.mp3')
                        pygame.mixer.music.set_volume(10.0)
                        pygame.mixer.music.play(loops=1)

                        #continue


                        pygame.mixer.music.load('music\EineLiebe.mp3')
                        pygame.mixer.music.set_volume(0.5)
                        pygame.mixer.music.play(loops=-1)
                        """




                    else:
                        i.shape('E:/Sokoban/Sokoban/picture/box.gif')
                    if set(box_space) == set(correct_box_space):
                        text.show_win()
                        #pass

            #pass

        #获取当前的坐标xcor()，ycor()
        #向上移动50
    def go_up(self):
        self.move(self.xcor(), self.ycor(), 0, 50)

    def go_down(self):
        self.move(self.xcor(), self.ycor(), 0, -50)

    def go_left(self):
        self.move(self.xcor(), self.ycor(), -50, 0)

    def go_right(self):
        self.move(self.xcor(), self.ycor(), 50, 0)


class Game():
    #画的方法
    def paint(self):
        #8行8列
        #X表示墙
        i_date = len(levels[num-1])
        j_date = len(levels[num-1][0])
        for i in range(i_date):
            for j in range(j_date):
                x = -j_date * 25 + 25 + j*50
                y =  i_date * 25 - 25 - i*50
                if levels[num-1][i][j] == ' ':
                    go_space.append((x, y))
                #X--墙
                if levels[num-1][i][j] == 'X':          #
                    #让这个海龟走的哪里去
                    wall.goto(x, y)
                    #没走到哪，在哪"盖一个章"
                    wall.stamp()
                #G、S、T、U、W设置空格区域的形状
                if levels[num-1][i][j] == 'R':
                    rock.goto(x, y)
                    rock.stamp()
                if levels[num-1][i][j] == 'S':
                    tree_short.goto(x, y)
                    tree_short.stamp()
                if levels[num-1][i][j] == 'T':
                    tree_tall.goto(x, y)
                    tree_tall.stamp()
                if levels[num-1][i][j] == 'U':
                    tree_ugly.goto(x, y)
                    tree_ugly.stamp()


                if levels[num-1][i][j] == 'O':          #
                    correct_box.goto(x, y)
                    correct_box.stamp()
                    go_space.append((x, y))
                    correct_box_space.append((x, y))
                if levels[num-1][i][j] == 'P':          #
                    player.goto(x, y)
                    go_space.append((x,y))
                if levels[num-1][i][j] == 'B':          #
                    box = Pen('E:/Sokoban/Sokoban/picture/box.gif')
                    #box = turtle.Turtle()
                    #box.shape('box.gif')
                    #box.pu()
                    box.goto(x, y)
                    box_list.append(box)
                    box_space.append((x, y))

#写字
class ShowMessage(turtle.Turtle):
    def __init__(self):
        #继承
        super().__init__()
        self.penup()
        self.pencolor('blue')
        self.ht()

    def message(self):
        self.goto(0, 290)
        #align对齐方式、字体(字体、字号、样式)
        self.write(f'第{num}关', align = 'center', font = ('仿宋', 20, 'bold'))
        self.goto(0, 270)
        self.write('重新开始本关请按回车键', align = 'center', font = ('仿宋', 15, 'bold'))
        self.goto(0, 250)
        self.write('选择关卡请按Q', align = 'center', font = ('仿宋', 15, 'bold'))

    def show_win(self):
        global num
        #判断关卡数：是增加1还是返回第一关
        if num == len(levels):
            num = 1
            self.goto(0,0)
            self.write('你已全部过关', align = 'center', font = ('仿宋', 30, 'bold'))
            self.goto(0,-50)
            self.write('返回第一关请按空格键', align = 'center', font = ('仿宋', 30, 'bold'))
        else:
            num = num + 1
            self.goto(0,0)
            self.write('恭喜通关', align = 'center', font = ('仿宋', 30, 'bold'))
            self.goto(0,-50)
            self.write('进入下一关请按空格键', align = 'center', font = ('仿宋', 30, 'bold'))

#每一关结束后清楚当前页面里的所有东西
def init():
    text.clear()
    wall.clear()
    tree_short.clear()
    tree_tall.clear()
    tree_ugly.clear()
    rock.clear()
    correct_box.clear()
    for i in box_list:
        i.ht()
        del(i)
    box_list.clear()
    box_space.clear()
    go_space.clear()
    correct_box_space.clear()
    game.paint()
    text.message()

def choose():
    global num
    a = ms.numinput('选择关卡', '你的选择（请输入1-5）', 1)
    if a is None:
        a = num
    num = int(a)
    init()
    ms.listen()

#实例化
num = 1
#正确箱子的列表
correct_box_space =[]
box_list = []
#箱子的位置
box_space = []
#把空白的地方表示出来
go_space = []
wall = Pen('E:/Sokoban/Sokoban/picture/wall.gif')
tree_short  = Pen('E:/Sokoban/Sokoban/picture/Tree_Short.gif')
tree_tall  = Pen('E:/Sokoban/Sokoban/picture/Tree_Tall.gif')
tree_ugly  = Pen('E:/Sokoban/Sokoban/picture/Tree_Ugly.gif')
rock = Pen('E:/Sokoban/Sokoban/picture/Rock.gif')
correct_box = Pen('E:/Sokoban/Sokoban/picture/o.gif')
player = Pen('E:/Sokoban/Sokoban/picture/p.gif')
game = Game()
game.paint()
text = ShowMessage()
text.message()

#监听
ms.listen()
#键盘控制
ms.onkey(player.go_up, 'Up')
ms.onkey(player.go_down, 'Down')
ms.onkey(player.go_left, 'Left')
ms.onkey(player.go_right, 'Right')
ms.onkey(init, 'Return')
ms.onkey(init, 'space')
ms.onkey(choose, 'Q')

#屏幕的更新
while True:
    ms.update()


ms.mainloop()
